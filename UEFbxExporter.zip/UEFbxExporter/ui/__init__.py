from .pie_menu import register as register_pie_menu, unregister as unregister_pie_menu

def register():
    register_pie_menu()

def unregister():
    unregister_pie_menu()